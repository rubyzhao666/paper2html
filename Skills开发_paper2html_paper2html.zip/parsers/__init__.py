"""
paper2html Skill - 解析层
将学术论文PDF转化为结构化数据
"""

from .doc2x_parser import Doc2XParser, ParseResult
from .ppx_parser import PPXParser
from .arxiv_handler import ArxivHandler

__all__ = [
    "Doc2XParser",
    "ParseResult",
    "PPXParser",
    "ArxivHandler",
]

__version__ = "0.1.0"
